#!/usr/bin/python
import os 
os.system('pip uninstall -r setup.txt')