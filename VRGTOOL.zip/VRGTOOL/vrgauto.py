#!/usr/bin/python
import os 
os.system('pip install -r setup.txt')
os.system('python vrgautomation.py')